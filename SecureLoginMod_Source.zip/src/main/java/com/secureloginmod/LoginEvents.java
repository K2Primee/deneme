package com.secureloginmod;

import com.secureloginmod.commands.LoginCommand;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.TextComponent;

@Mod.EventBusSubscriber
public class LoginEvents {

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (!(event.player instanceof ServerPlayer player)) return;
        if (!LoginCommand.isLoggedIn(player)) {
            player.setDeltaMovement(0, 0, 0); // Hareketi durdur
            player.resetFallDistance(); // Düşme hasarı alma
        }
    }

    @SubscribeEvent
    public static void onBlockBreak(PlayerEvent.BreakSpeed event) {
        if (!(event.getPlayer() instanceof ServerPlayer player)) return;
        if (!LoginCommand.isLoggedIn(player)) {
            event.setCanceled(true);
            player.sendSystemMessage(new TextComponent("Giriş yapmadan blok kıramazsınız."));
        }
    }

    @SubscribeEvent
    public static void onRightClick(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getPlayer() instanceof ServerPlayer player)) return;
        if (!LoginCommand.isLoggedIn(player)) {
            event.setCanceled(true);
            player.sendSystemMessage(new TextComponent("Giriş yapmadan etkileşim yapamazsınız."));
        }
    }
}
