package com.secureloginmod;

import java.nio.file.*;
import java.util.*;
import java.io.*;
import java.security.MessageDigest;

public class PlayerDataManager {
    private static final Path dataDir = Paths.get("world/secureloginmod");

    static {
        if (!Files.exists(dataDir)) {
            try {
                Files.createDirectories(dataDir);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static boolean isRegistered(String uuid) {
        return Files.exists(dataDir.resolve(uuid + ".dat"));
    }

    public static void register(String uuid, String password) throws Exception {
        String hashed = hash(password);
        Files.write(dataDir.resolve(uuid + ".dat"), hashed.getBytes());
    }

    public static boolean checkPassword(String uuid, String password) throws Exception {
        Path file = dataDir.resolve(uuid + ".dat");
        if (!Files.exists(file)) return false;
        String stored = new String(Files.readAllBytes(file));
        return stored.equals(hash(password));
    }

    private static String hash(String input) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(input.getBytes("UTF-8"));
        StringBuilder hex = new StringBuilder();
        for (byte b : hash) {
            hex.append(String.format("%02x", b));
        }
        return hex.toString();
    }
}
