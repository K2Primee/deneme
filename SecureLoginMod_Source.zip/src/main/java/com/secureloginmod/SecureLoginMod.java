package com.secureloginmod;

import net.minecraftforge.fml.common.Mod;

@Mod("secureloginmod")
public class SecureLoginMod {
    public SecureLoginMod() {
        // Başlangıçta çalışacak kod buraya gelecek
    }
}
