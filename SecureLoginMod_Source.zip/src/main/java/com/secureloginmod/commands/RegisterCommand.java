package com.secureloginmod.commands;

import com.secureloginmod.PlayerDataManager;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.level.ServerPlayer;

public class RegisterCommand {
    public static void register(net.minecraftforge.event.RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("register")
            .then(Commands.argument("password", StringArgumentType.word())
            .then(Commands.argument("confirm", StringArgumentType.word())
            .executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayerOrException();
                String uuid = player.getStringUUID();
                String pass = StringArgumentType.getString(ctx, "password");
                String confirm = StringArgumentType.getString(ctx, "confirm");

                if (!pass.equals(confirm)) {
                    player.sendSystemMessage(new TextComponent("Şifreler eşleşmiyor!"));
                    return Command.SINGLE_SUCCESS;
                }

                if (PlayerDataManager.isRegistered(uuid)) {
                    player.sendSystemMessage(new TextComponent("Zaten kayıtlısınız."));
                    return Command.SINGLE_SUCCESS;
                }

                try {
                    PlayerDataManager.register(uuid, pass);
                    player.sendSystemMessage(new TextComponent("Başarıyla kayıt oldunuz!"));
                } catch (Exception e) {
                    player.sendSystemMessage(new TextComponent("Kayıt sırasında hata oluştu."));
                }
                return Command.SINGLE_SUCCESS;
            }))));
    }
}
