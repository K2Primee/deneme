package com.secureloginmod.commands;

import com.secureloginmod.PlayerDataManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.commands.Commands;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.Command;

import java.util.HashSet;
import java.util.Set;

public class LoginCommand {
    public static final Set<String> loggedInPlayers = new HashSet<>();

    public static void register(net.minecraftforge.event.RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("login")
            .then(Commands.argument("password", StringArgumentType.word())
            .executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayerOrException();
                String uuid = player.getStringUUID();
                String pass = StringArgumentType.getString(ctx, "password");

                try {
                    if (!PlayerDataManager.isRegistered(uuid)) {
                        player.sendSystemMessage(new TextComponent("Önce kayıt olmanız gerekiyor!"));
                        return Command.SINGLE_SUCCESS;
                    }

                    if (PlayerDataManager.checkPassword(uuid, pass)) {
                        loggedInPlayers.add(uuid);
                        player.sendSystemMessage(new TextComponent("Başarıyla giriş yaptınız!"));
                    } else {
                        player.sendSystemMessage(new TextComponent("Şifre yanlış!"));
                    }
                } catch (Exception e) {
                    player.sendSystemMessage(new TextComponent("Giriş sırasında hata oluştu."));
                }
                return Command.SINGLE_SUCCESS;
            })));
    }

    public static boolean isLoggedIn(ServerPlayer player) {
        return loggedInPlayers.contains(player.getStringUUID());
    }
}
